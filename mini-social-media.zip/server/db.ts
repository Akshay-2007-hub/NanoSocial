import fs from "fs";
import path from "path";

export interface User {
  id: string;
  username: string;
  email: string;
  password_hash: string;
  bio: string;
  avatar_url: string;
  created_at: string;
}

export interface Post {
  id: string;
  user_id: string;
  content: string;
  image_url: string;
  created_at: string;
}

export interface Comment {
  id: string;
  post_id: string;
  user_id: string;
  text: string;
  created_at: string;
}

export interface Like {
  id: string;
  post_id: string;
  user_id: string;
}

export interface Follower {
  id: string;
  follower_id: string; // the user who is following
  following_id: string; // the user being followed
}

export interface Schema {
  users: User[];
  posts: Post[];
  comments: Comment[];
  likes: Like[];
  followers: Follower[];
}

const DB_FILE = path.join(process.cwd(), "db.json");

const DEFAULT_AVATARS = [
  "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&h=150&fit=crop&crop=face", // Sarah
  "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face", // Alex
  "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop&crop=face", // Elena
  "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&h=150&fit=crop&crop=face", // Marcus
  "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face", // Maya
];

const DEFAULT_POST_IMAGES = [
  "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=600&h=400&fit=crop", // Nature
  "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=600&h=400&fit=crop", // Tech
  "https://images.unsplash.com/photo-1511556532299-8f662fc26c06?w=600&h=400&fit=crop", // Design Minimal
  "https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=600&h=400&fit=crop", // Delicious Food
];

function getInitialData(): Schema {
  // Let's seed with some premium, beautiful accounts for a rich, dynamic experience
  const sashaHash = "$2a$10$pL3m1b0y1078B5f3IAtFdu.aFfWzJ8RGrT.gU280Kq4G67WbUun6O"; // bcrypt hash for 'password123'
  const alexHash = "$2a$10$pL3m1b0y1078B5f3IAtFdu.aFfWzJ8RGrT.gU280Kq4G67WbUun6O";
  const elenaHash = "$2a$10$pL3m1b0y1078B5f3IAtFdu.aFfWzJ8RGrT.gU280Kq4G67WbUun6O";

  const users: User[] = [
    {
      id: "u1",
      username: "designer_sara",
      email: "sara@design.co",
      password_hash: sashaHash,
      bio: "Visual Designer & Minimalist. Crafting experiences that spark joy ✨ | Based in SF",
      avatar_url: DEFAULT_AVATARS[0],
      created_at: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
    },
    {
      id: "u2",
      username: "alex_tech",
      email: "alex@techlabs.io",
      password_hash: alexHash,
      bio: "Full Stack Engineer | Open source enthusiast. Let's build things that matter! 🚀💻 Code is life.",
      avatar_url: DEFAULT_AVATARS[1],
      created_at: new Date(Date.now() - 25 * 24 * 60 * 60 * 1000).toISOString(),
    },
    {
      id: "u3",
      username: "elena_travels",
      email: "elena@wander.com",
      password_hash: elenaHash,
      bio: "Travel Photographer & Storyteller ✈️📸. Exploring the hidden corners of our beautiful planet.",
      avatar_url: DEFAULT_AVATARS[2],
      created_at: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString(),
    },
  ];

  const posts: Post[] = [
    {
      id: "p1",
      user_id: "u1",
      content: "Just finished designing the visual interface for a new spatial computing applet. The power of negative space and crisp typography cannot be overstated! Understated design is so powerful.",
      image_url: DEFAULT_POST_IMAGES[2],
      created_at: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(), // 2 hrs ago
    },
    {
      id: "p2",
      user_id: "u2",
      content: "Spent my morning optimizing database queries and server latency. Managed to slice our load times in half! There's no feeling quite like seeing a perfectly straight line on a latency metric chart. 🏎️💨",
      image_url: "",
      created_at: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString(), // 5 hrs ago
    },
    {
      id: "p3",
      user_id: "u3",
      content: "Caught the absolute perfect sunrise high up in the Swiss Alps this morning. Worth every single painful step of the mountain climb. Nature never fails to leave me completely wordless. 🏔️🌤️",
      image_url: DEFAULT_POST_IMAGES[0],
      created_at: new Date(Date.now() - 20 * 60 * 60 * 1000).toISOString(), // 20 hrs ago
    }
  ];

  const comments: Comment[] = [
    {
      id: "c1",
      post_id: "p1",
      user_id: "u2",
      text: "This is breathtakingly clean! What font is that in the mockup? Would love to use it on my next project.",
      created_at: new Date(Date.now() - 1 * 60 * 60 * 1000).toISOString(),
    },
    {
      id: "c2",
      post_id: "p1",
      user_id: "u1",
      text: "Thanks Alex! It's 'Space Grotesk' paired with elegant margins. Highly recommend it! 🙌",
      created_at: new Date(Date.now() - 50 * 60 * 1000).toISOString(),
    },
    {
      id: "c3",
      post_id: "p3",
      user_id: "u1",
      text: "Wow... those warm color tones on the mountain crest are absolutely beautiful! What focal length did you use?",
      created_at: new Date(Date.now() - 18 * 60 * 60 * 1000).toISOString(),
    },
    {
      id: "c4",
      post_id: "p3",
      user_id: "u3",
      text: "Thank you! I shot this on a 24-70mm lens set at 35mm. The light only lasted about two minutes!",
      created_at: new Date(Date.now() - 17 * 60 * 60 * 1000).toISOString(),
    }
  ];

  const likes: Like[] = [
    { id: "l1", post_id: "p1", user_id: "u2" },
    { id: "l2", post_id: "p1", user_id: "u3" },
    { id: "l3", post_id: "p2", user_id: "u1" },
    { id: "l4", post_id: "p3", user_id: "u2" },
  ];

  // Make them follow each other initially for a connected feel
  const followers: Follower[] = [
    { id: "f1", follower_id: "u1", following_id: "u2" }, // Sara follows Alex
    { id: "f2", follower_id: "u1", following_id: "u3" }, // Sara follows Elena
    { id: "f3", follower_id: "u2", following_id: "u1" }, // Alex follows Sara
    { id: "f4", follower_id: "u3", following_id: "u1" }, // Elena follows Sara
    { id: "f5", follower_id: "u3", following_id: "u2" }, // Elena follows Alex
  ];

  return { users, posts, comments, likes, followers };
}

export function readDB(): Schema {
  try {
    if (!fs.existsSync(DB_FILE)) {
      const data = getInitialData();
      writeDB(data);
      return data;
    }
    const content = fs.readFileSync(DB_FILE, "utf-8");
    return JSON.parse(content);
  } catch (error) {
    console.error("Error reading database file, returning initial schema", error);
    return getInitialData();
  }
}

export function writeDB(data: Schema): void {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), "utf-8");
  } catch (error) {
    console.error("Error writing database file", error);
  }
}
