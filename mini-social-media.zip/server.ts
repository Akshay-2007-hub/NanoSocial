import express from "express";
import path from "path";
import fs from "fs";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { createServer as createViteServer } from "vite";
import { readDB, writeDB, User, Post, Comment, Like, Follower } from "./server/db";

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
const JWT_SECRET = process.env.JWT_SECRET || "mini-social-jwt-secret-key-2026";

app.use(express.json({ limit: "10mb" })); // Allow larger payloads for optional base64 profile pictures

// Middleware to authenticate JWT token
function authenticateToken(req: express.Request, res: express.Response, next: express.NextFunction) {
  const authHeader = req.headers["authorization"];
  const token = authHeader && authHeader.split(" ")[1];

  if (!token) {
    res.status(401).json({ error: "Access token required" });
    return;
  }

  jwt.verify(token, JWT_SECRET, (err, decoded) => {
    if (err) {
      res.status(403).json({ error: "Invalid or expired token" });
      return;
    }
    (req as any).user = decoded;
    next();
  });
}

// REST API Endpoints

// 1. Auth: Register
app.post("/api/auth/register", (req, res) => {
  const { username, email, password, bio, avatar_url } = req.body;

  if (!username || !email || !password) {
    res.status(400).json({ error: "Username, email, and password are required" });
    return;
  }

  const db = readDB();
  
  // Check if username or email already exists
  const userExists = db.users.some(
    (u) => u.username.toLowerCase() === username.toLowerCase() || u.email.toLowerCase() === email.toLowerCase()
  );

  if (userExists) {
    res.status(400).json({ error: "Username or email is already taken" });
    return;
  }

  const salt = bcrypt.genSaltSync(10);
  const password_hash = bcrypt.hashSync(password, salt);

  const newUser: User = {
    id: "u_" + Math.random().toString(36).substring(2, 11),
    username,
    email,
    password_hash,
    bio: bio || "",
    avatar_url: avatar_url || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&h=150&fit=crop",
    created_at: new Date().toISOString(),
  };

  db.users.push(newUser);
  writeDB(db);

  // Generate JWT token
  const token = jwt.sign({ id: newUser.id, username: newUser.username }, JWT_SECRET, { expiresIn: "7d" });

  const { password_hash: _, ...userWithoutPassword } = newUser;
  res.status(201).json({ token, user: userWithoutPassword });
});

// 2. Auth: Login
app.post("/api/auth/login", (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    res.status(400).json({ error: "Username and password are required" });
    return;
  }

  const db = readDB();
  const user = db.users.find(
    (u) => u.username.toLowerCase() === username.toLowerCase() || u.email.toLowerCase() === username.toLowerCase()
  );

  if (!user || !bcrypt.compareSync(password, user.password_hash)) {
    res.status(401).json({ error: "Invalid username or password" });
    return;
  }

  const token = jwt.sign({ id: user.id, username: user.username }, JWT_SECRET, { expiresIn: "7d" });

  const { password_hash: _, ...userWithoutPassword } = user;
  res.json({ token, user: userWithoutPassword });
});

// Helper: Query user utility
function getUserProfileWithStats(targetUserIdOrName: string, currentUserId?: string) {
  const db = readDB();
  const user = db.users.find(
    (u) => u.id === targetUserIdOrName || u.username.toLowerCase() === targetUserIdOrName.toLowerCase()
  );

  if (!user) return null;

  const posts_count = db.posts.filter((p) => p.user_id === user.id).length;
  const followers_count = db.followers.filter((f) => f.following_id === user.id).length;
  const following_count = db.followers.filter((f) => f.follower_id === user.id).length;

  const is_following = currentUserId
    ? db.followers.some((f) => f.follower_id === currentUserId && f.following_id === user.id)
    : false;

  const { password_hash: _, ...userWithoutPassword } = user;

  return {
    ...userWithoutPassword,
    posts_count,
    followers_count,
    following_count,
    is_following,
  };
}

// 3. User Listing/Search
app.get("/api/users", authenticateToken, (req, res) => {
  const q = req.query.q as string;
  const db = readDB();
  const currentUserId = (req as any).user.id;

  let filteredUsers = db.users.filter((u) => u.id !== currentUserId);

  if (q) {
    const query = q.toLowerCase();
    filteredUsers = filteredUsers.filter(
      (u) => u.username.toLowerCase().includes(query) || (u.bio && u.bio.toLowerCase().includes(query))
    );
  }

  const result = filteredUsers.map((u) => {
    const followers_count = db.followers.filter((f) => f.following_id === u.id).length;
    const is_following = db.followers.some((f) => f.follower_id === currentUserId && f.following_id === u.id);
    return {
      id: u.id,
      username: u.username,
      bio: u.bio,
      avatar_url: u.avatar_url,
      followers_count,
      is_following,
    };
  });

  res.json(result);
});

// 4. Get profile
app.get("/api/users/:id", (req, res) => {
  // Check authorization header optionally for follow checks
  let currentUserId: string | undefined = undefined;
  const authHeader = req.headers["authorization"];
  if (authHeader && authHeader.split(" ")[1]) {
    try {
      const decoded = jwt.verify(authHeader.split(" ")[1], JWT_SECRET) as any;
      currentUserId = decoded.id;
    } catch (e) {
      // Ignore invalid optional tokens
    }
  }

  const profile = getUserProfileWithStats(req.params.id, currentUserId);
  if (!profile) {
    res.status(404).json({ error: "User not found" });
    return;
  }
  res.json(profile);
});

// 5. Update profile
app.put("/api/users/:id", authenticateToken, (req, res) => {
  const authenticatedUserId = (req as any).user.id;
  const targetId = req.params.id;

  const db = readDB();
  const userIndex = db.users.findIndex((u) => u.id === targetId);

  if (userIndex === -1) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  if (db.users[userIndex].id !== authenticatedUserId) {
    res.status(403).json({ error: "Unauthorized to edit this profile" });
    return;
  }

  const { bio, avatar_url, email } = req.body;

  if (bio !== undefined) db.users[userIndex].bio = bio;
  if (avatar_url !== undefined) db.users[userIndex].avatar_url = avatar_url;
  if (email !== undefined) db.users[userIndex].email = email;

  writeDB(db);

  const updatedProfile = getUserProfileWithStats(targetId, authenticatedUserId);
  res.json(updatedProfile);
});

// Utility to assemble full post structures including comments, likes, and is_liked
function assemblePost(post: Post, currentUserId: string, db: { users: User[]; likes: Like[]; comments: Comment[] }) {
  const author = db.users.find((u) => u.id === post.user_id);
  const likes_count = db.likes.filter((l) => l.post_id === post.id).length;
  const comments_count = db.comments.filter((c) => c.post_id === post.id).length;
  const is_liked = db.likes.some((l) => l.post_id === post.id && l.user_id === currentUserId);

  return {
    ...post,
    author: author ? {
      id: author.id,
      username: author.username,
      avatar_url: author.avatar_url,
    } : {
      id: post.user_id,
      username: "unknown",
      avatar_url: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&h=150&fit=crop",
    },
    likes_count,
    comments_count,
    is_liked,
  };
}

// 6. Get home feed (posts from followed users + own posts)
app.get("/api/posts/feed", authenticateToken, (req, res) => {
  const currentUserId = (req as any).user.id;
  const db = readDB();

  // Find the list of user IDs being followed
  const followedIds = db.followers
    .filter((f) => f.follower_id === currentUserId)
    .map((f) => f.following_id);

  // Include own user ID
  const whitelistUserIds = [...followedIds, currentUserId];

  const feedPosts = db.posts
    .filter((p) => whitelistUserIds.includes(p.user_id))
    .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

  const result = feedPosts.map((post) => assemblePost(post, currentUserId, db));
  res.json(result);
});

// 7. Get explore feed (trending/recent posts from all users)
app.get("/api/posts/explore", authenticateToken, (req, res) => {
  const currentUserId = (req as any).user.id;
  const db = readDB();

  const allPosts = [...db.posts].sort(
    (a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
  );

  const result = allPosts.map((post) => assemblePost(post, currentUserId, db));
  res.json(result);
});

// 8. Create post
app.post("/api/posts", authenticateToken, (req, res) => {
  const { content, image_url } = req.body;
  const currentUserId = (req as any).user.id;

  if (!content) {
    res.status(400).json({ error: "Post content is required" });
    return;
  }

  const db = readDB();

  const newPost: Post = {
    id: "p_" + Math.random().toString(36).substring(2, 11),
    user_id: currentUserId,
    content,
    image_url: image_url || "",
    created_at: new Date().toISOString(),
  };

  db.posts.push(newPost);
  writeDB(db);

  const formattedPost = assemblePost(newPost, currentUserId, db);
  res.status(201).json(formattedPost);
});

// 9. Delete post
app.delete("/api/posts/:id", authenticateToken, (req, res) => {
  const currentUserId = (req as any).user.id;
  const postId = req.params.id;

  const db = readDB();
  const postIndex = db.posts.findIndex((p) => p.id === postId);

  if (postIndex === -1) {
    res.status(404).json({ error: "Post not found" });
    return;
  }

  if (db.posts[postIndex].user_id !== currentUserId) {
    res.status(403).json({ error: "Unauthorized to delete this post" });
    return;
  }

  // Remove the post
  db.posts.splice(postIndex, 1);

  // Cascade delete likes and comments associated with this post
  db.likes = db.likes.filter((l) => l.post_id !== postId);
  db.comments = db.comments.filter((c) => c.post_id !== postId);

  writeDB(db);
  res.json({ message: "Post and its engagements deleted successfully" });
});

// 10. Toggle like status
app.post("/api/posts/:id/like", authenticateToken, (req, res) => {
  const currentUserId = (req as any).user.id;
  const postId = req.params.id;

  const db = readDB();
  const postExists = db.posts.some((p) => p.id === postId);

  if (!postExists) {
    res.status(404).json({ error: "Post not found" });
    return;
  }

  const likeIndex = db.likes.findIndex((l) => l.post_id === postId && l.user_id === currentUserId);
  let liked = false;

  if (likeIndex > -1) {
    // Already liked, toggle to unlike
    db.likes.splice(likeIndex, 1);
  } else {
    // Create like record
    db.likes.push({
      id: "l_" + Math.random().toString(36).substring(2, 11),
      post_id: postId,
      user_id: currentUserId,
    });
    liked = true;
  }

  writeDB(db);

  const likes_count = db.likes.filter((l) => l.post_id === postId).length;
  res.json({ liked, likes_count });
});

// 11. Get all comments for a post
app.get("/api/posts/:id/comments", authenticateToken, (req, res) => {
  const postId = req.params.id;
  const db = readDB();

  const comments = db.comments
    .filter((c) => c.post_id === postId)
    .map((c) => {
      const user = db.users.find((u) => u.id === c.user_id);
      return {
        ...c,
        username: user ? user.username : "unknown",
        avatar_url: user ? user.avatar_url : "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&h=150&fit=crop",
      };
    });

  res.json(comments);
});

// 12. Add a comment to a post
app.post("/api/posts/:id/comments", authenticateToken, (req, res) => {
  const postId = req.params.id;
  const { text } = req.body;
  const currentUserId = (req as any).user.id;

  if (!text) {
    res.status(400).json({ error: "Comment text is required" });
    return;
  }

  const db = readDB();
  const postExists = db.posts.some((p) => p.id === postId);

  if (!postExists) {
    res.status(404).json({ error: "Post not found" });
    return;
  }

  const newComment: Comment = {
    id: "c_" + Math.random().toString(36).substring(2, 11),
    post_id: postId,
    user_id: currentUserId,
    text,
    created_at: new Date().toISOString(),
  };

  db.comments.push(newComment);
  writeDB(db);

  const commenter = db.users.find((u) => u.id === currentUserId);

  res.status(201).json({
    ...newComment,
    username: commenter?.username || "unknown",
    avatar_url: commenter?.avatar_url || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&h=150&fit=crop",
  });
});

// 13. Delete comment
app.delete("/api/comments/:id", authenticateToken, (req, res) => {
  const currentUserId = (req as any).user.id;
  const commentId = req.params.id;

  const db = readDB();
  const commentIndex = db.comments.findIndex((c) => c.id === commentId);

  if (commentIndex === -1) {
    res.status(404).json({ error: "Comment not found" });
    return;
  }

  const comment = db.comments[commentIndex];
  const post = db.posts.find((p) => p.id === comment.post_id);

  // Author of the comment OR author of the parent post can delete the comment
  const isCommentOwner = comment.user_id === currentUserId;
  const isPostOwner = post && post.user_id === currentUserId;

  if (!isCommentOwner && !isPostOwner) {
    res.status(403).json({ error: "Unauthorized to delete this comment" });
    return;
  }

  db.comments.splice(commentIndex, 1);
  writeDB(db);

  res.json({ message: "Comment deleted successfully" });
});

// 14. Follow / Unfollow toggle
app.post("/api/users/:id/follow", authenticateToken, (req, res) => {
  const currentUserId = (req as any).user.id;
  const targetIdOrName = req.params.id;

  const db = readDB();
  const targetUser = db.users.find(
    (u) => u.id === targetIdOrName || u.username.toLowerCase() === targetIdOrName.toLowerCase()
  );

  if (!targetUser) {
    res.status(404).json({ error: "User to follow not found" });
    return;
  }

  if (targetUser.id === currentUserId) {
    res.status(400).json({ error: "You cannot follow yourself" });
    return;
  }

  const followIndex = db.followers.findIndex(
    (f) => f.follower_id === currentUserId && f.following_id === targetUser.id
  );

  let following = false;

  if (followIndex > -1) {
    // Already following, unfollow
    db.followers.splice(followIndex, 1);
  } else {
    // Create follow relationship
    db.followers.push({
      id: "f_" + Math.random().toString(36).substring(2, 11),
      follower_id: currentUserId,
      following_id: targetUser.id,
    });
    following = true;
  }

  writeDB(db);

  const updatedTargetProfile = getUserProfileWithStats(targetUser.id, currentUserId);
  res.json({ following, profile: updatedTargetProfile });
});

// 15. List followers
app.get("/api/users/:id/followers", authenticateToken, (req, res) => {
  const targetUserIdentifier = req.params.id;
  const db = readDB();

  const targetUser = db.users.find(
    (u) => u.id === targetUserIdentifier || u.username.toLowerCase() === targetUserIdentifier.toLowerCase()
  );

  if (!targetUser) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  const followerRelations = db.followers.filter((f) => f.following_id === targetUser.id);
  const followerUsers = followerRelations.map((f) => {
    const user = db.users.find((u) => u.id === f.follower_id);
    const is_following_back = db.followers.some(
      (rel) => rel.follower_id === (req as any).user.id && rel.following_id === f.follower_id
    );
    return {
      id: user?.id,
      username: user?.username,
      bio: user?.bio,
      avatar_url: user?.avatar_url,
      is_following: is_following_back,
    };
  });

  res.json(followerUsers);
});

// 16. List following
app.get("/api/users/:id/following", authenticateToken, (req, res) => {
  const targetUserIdentifier = req.params.id;
  const db = readDB();

  const targetUser = db.users.find(
    (u) => u.id === targetUserIdentifier || u.username.toLowerCase() === targetUserIdentifier.toLowerCase()
  );

  if (!targetUser) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  const followingRelations = db.followers.filter((f) => f.follower_id === targetUser.id);
  const followingUsers = followingRelations.map((f) => {
    const user = db.users.find((u) => u.id === f.following_id);
    const is_following = db.followers.some(
      (rel) => rel.follower_id === (req as any).user.id && rel.following_id === f.following_id
    );
    return {
      id: user?.id,
      username: user?.username,
      bio: user?.bio,
      avatar_url: user?.avatar_url,
      is_following,
    };
  });

  res.json(followingUsers);
});

// 17. Get single post (bonus/helpful route for single post display pages)
app.get("/api/posts/:id", authenticateToken, (req, res) => {
  const postId = req.params.id;
  const db = readDB();
  const currentUserId = (req as any).user.id;

  const post = db.posts.find((p) => p.id === postId);

  if (!post) {
    res.status(404).json({ error: "Post not found" });
    return;
  }

  const result = assemblePost(post, currentUserId, db);
  res.json(result);
});

// Catch-all for unmatched API routes
app.all("/api/*", (req, res) => {
  res.status(404).json({ error: "API route not found" });
});

// Vite Middleware for development & Production static file serving
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server is running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
