import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { AuthUser, Route, Toast } from "../types";

export interface AppContextProps {
  user: AuthUser | null;
  token: string | null;
  currentRoute: Route;
  toasts: Toast[];
  isLoading: boolean;
  setLoading: (loading: boolean) => void;
  showToast: (message: string, type?: "success" | "error" | "info") => void;
  removeToast: (id: string) => void;
  login: (user: AuthUser, token: string) => void;
  logout: () => void;
  navigate: (routeName: Route["name"], params?: Route["params"]) => void;
  updateUserInContext: (updatedUser: Partial<AuthUser>) => void;
  apiFetch: <T = any>(endpoint: string, options?: RequestInit) => Promise<T>;
}

const AppContext = createContext<AppContextProps | undefined>(undefined);

// Helper to parse hash to Route
function parseHash(hash: string): Route {
  if (!hash || hash === "#" || hash === "#/") {
    return { name: "feed" };
  }

  const cleanHash = hash.replace(/^#\/?/, ""); // strip #/ or #
  const parts = cleanHash.split("/");

  const name = parts[0] as Route["name"];
  const params: Record<string, string> = {};

  if (name === "profile" && parts[1]) {
    params.username = parts[1];
  } else if (name === "post" && parts[1]) {
    params.id = parts[1];
  } else if (name === "search" && parts[1]) {
    params.q = decodeURIComponent(parts[1]);
  }

  const validRoutes: Route["name"][] = ["login", "register", "feed", "explore", "profile", "post", "search"];
  if (validRoutes.includes(name)) {
    return { name, params };
  }

  return { name: "feed" };
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [currentRoute, setCurrentRoute] = useState<Route>({ name: "feed" });
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  // Initialize auth from localStorage & parse starting URL hash
  useEffect(() => {
    const storedToken = localStorage.getItem("mini_social_token");
    const storedUser = localStorage.getItem("mini_social_user");

    if (storedToken && storedUser) {
      setToken(storedToken);
      try {
        setUser(JSON.parse(storedUser));
      } catch (e) {
        localStorage.removeItem("mini_social_token");
        localStorage.removeItem("mini_social_user");
      }
    }

    // Set route from starting hash
    const initialRoute = parseHash(window.location.hash);
    
    // Auth Guard: redirect unauthenticated users to login
    if (!storedToken && initialRoute.name !== "register") {
      setCurrentRoute({ name: "login" });
      window.location.hash = "#/login";
    } else {
      setCurrentRoute(initialRoute);
    }

    // Bind hash change listener
    const handleHashChange = () => {
      const parsed = parseHash(window.location.hash);
      const isAuthToken = localStorage.getItem("mini_social_token");
      
      if (!isAuthToken && parsed.name !== "register" && parsed.name !== "login") {
        setCurrentRoute({ name: "login" });
        window.location.hash = "#/login";
      } else {
        setCurrentRoute(parsed);
      }
    };

    window.addEventListener("hashchange", handleHashChange);
    return () => window.removeEventListener("hashchange", handleHashChange);
  }, []);

  const navigate = (routeName: Route["name"], params?: Route["params"]) => {
    let hash = `#/${routeName}`;
    if (routeName === "profile" && params?.username) {
      hash += `/${params.username}`;
    } else if (routeName === "post" && params?.id) {
      hash += `/${params.id}`;
    } else if (routeName === "search" && params?.q) {
      hash += `/${encodeURIComponent(params.q)}`;
    }
    window.location.hash = hash;
  };

  const login = (userData: AuthUser, authToken: string) => {
    setUser(userData);
    setToken(authToken);
    localStorage.setItem("mini_social_token", authToken);
    localStorage.setItem("mini_social_user", JSON.stringify(userData));
    showToast(`Welcome back, @${userData.username}!`, "success");
    navigate("feed");
  };

  const logout = () => {
    showToast("Successfully logged out.", "info");
    setUser(null);
    setToken(null);
    localStorage.removeItem("mini_social_token");
    localStorage.removeItem("mini_social_user");
    navigate("login");
  };

  const updateUserInContext = (updatedData: Partial<AuthUser>) => {
    if (user) {
      const merged = { ...user, ...updatedData };
      setUser(merged);
      localStorage.setItem("mini_social_user", JSON.stringify(merged));
    }
  };

  const showToast = (message: string, type: Toast["type"] = "success") => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      removeToast(id);
    }, 4000);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const apiFetch = async <T = any>(endpoint: string, options: RequestInit = {}): Promise<T> => {
    setIsLoading(true);

    const activeToken = token || localStorage.getItem("mini_social_token");

    const defaultHeaders: Record<string, string> = {
      "Content-Type": "application/json",
    };

    if (activeToken) {
      defaultHeaders["Authorization"] = `Bearer ${activeToken}`;
    }

    const config: RequestInit = {
      ...options,
      headers: {
        ...defaultHeaders,
        ...options.headers,
      },
    };

    try {
      const res = await fetch(endpoint, config);
      const data = await res.json();
      
      if (!res.ok) {
        // If expired token
        if (res.status === 401 || res.status === 403) {
          if (user) {
            logout();
          }
        }
        throw new Error(data.error || "An error occurred during request.");
      }
      return data as T;
    } catch (error: any) {
      console.error("API error:", error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <AppContext.Provider
      value={{
        user,
        token,
        currentRoute,
        toasts,
        isLoading,
        setLoading: setIsLoading,
        showToast,
        removeToast,
        login,
        logout,
        navigate,
        updateUserInContext,
        apiFetch,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error("useApp must be used within an AppProvider");
  }
  return context;
}
