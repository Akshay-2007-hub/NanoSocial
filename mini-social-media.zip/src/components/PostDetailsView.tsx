import React, { useState, useEffect } from "react";
import { useApp } from "../context/AppContext";
import { LoadingSpinner } from "./Feedback";
import PostCard from "./PostCard";
import { PostType, CommentType } from "../types";
import { formatRelativeTime } from "../utils/date";
import { Send, Trash2, ArrowLeft, MessageCircle } from "lucide-react";

export default function PostDetailsView({ postId }: { postId: string }) {
  const { user, apiFetch, showToast, navigate } = useApp();
  
  const [post, setPost] = useState<PostType | null>(null);
  const [comments, setComments] = useState<CommentType[]>([]);
  const [commentText, setCommentText] = useState("");
  const [loading, setLoading] = useState(true);
  const [commentsLoading, setCommentsLoading] = useState(false);
  const [submittingComment, setSubmittingComment] = useState(false);

  const fetchPostAndComments = async () => {
    setLoading(true);
    try {
      // 1. Get detailed post card
      const postData = await apiFetch<PostType>(`/api/posts/${postId}`);
      setPost(postData);

      // 2. Get comments list
      setCommentsLoading(true);
      const commentsData = await apiFetch<CommentType[]>(`/api/posts/${postId}/comments`);
      setComments(commentsData);

    } catch (e: any) {
      showToast(e.message || "Failed to load post snapshot", "error");
    } finally {
      setLoading(false);
      setCommentsLoading(false);
    }
  };

  useEffect(() => {
    fetchPostAndComments();
  }, [postId]);

  const handleCreateComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim()) return;

    setSubmittingComment(true);
    try {
      const newComment = await apiFetch<CommentType>(`/api/posts/${postId}/comments`, {
        method: "POST",
        body: JSON.stringify({ text: commentText.trim() }),
      });

      setComments((prev) => [...prev, newComment]);
      setCommentText("");
      showToast("Comment added", "success");

      // Update local comment count on post card
      if (post) {
        setPost({ ...post, comments_count: post.comments_count + 1 });
      }
    } catch (e: any) {
      showToast(e.message || "Failed to drop your comment", "error");
    } finally {
      setSubmittingComment(false);
    }
  };

  const handleDeleteComment = async (commentId: string) => {
    try {
      await apiFetch(`/api/comments/${commentId}`, { method: "DELETE" });
      setComments((prev) => prev.filter((c) => c.id !== commentId));
      showToast("Comment deleted successfully", "success");

      // Update local comment count on post card
      if (post) {
        setPost({ ...post, comments_count: Math.max(0, post.comments_count - 1) });
      }
    } catch (e: any) {
      showToast(e.message || "Action unauthorized", "error");
    }
  };

  if (loading) {
    return <LoadingSpinner size="large" />;
  }

  if (!post) {
    return (
      <div className="text-center py-12" id="post-not-found">
        <h2 className="font-heading font-extrabold text-xl text-slate-900">Post Not Found</h2>
        <p className="text-slate-500 text-sm mt-1 font-mono">The specified update ID does not exist or was deleted.</p>
        <button 
          onClick={() => navigate("feed")} 
          className="mt-6 px-4 py-2 bg-indigo-650 hover:bg-indigo-700 text-white font-semibold text-xs rounded-xl cursor-pointer"
        >
          Return to Feed
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6 animate-in fade-in duration-250" id={`post-details-${post.id}`}>
      
      {/* Back button */}
      <div className="flex items-center">
        <button
          onClick={() => navigate("feed")}
          className="flex items-center gap-2 text-xs font-bold text-slate-500 hover:text-[#6366f1] transition-colors p-1.5 hover:bg-slate-50 rounded-xl cursor-pointer"
          id="btn-back-to-feed"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Feed</span>
        </button>
      </div>

      {/* Primary Post Card display */}
      <PostCard post={post} onPostDeleted={() => navigate("feed")} />

      {/* Comments section card */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 shadow-sm" id="comments-container">
        <h3 className="font-sans font-bold text-sm text-slate-900 mb-6 flex items-center gap-2">
          <MessageCircle className="w-4.5 h-4.5 text-[#6366f1]" />
          Comments Thread ({comments.length})
        </h3>

        {/* Comment creator Composer Form */}
        {user && (
          <form onSubmit={handleCreateComment} className="flex gap-3 mb-6" id="comment-composer-form">
            <img
              src={user.avatar_url}
              alt={user.username}
              className="w-8 h-8 rounded-full object-cover flex-shrink-0 border border-slate-150"
            />
            <div className="flex-grow flex gap-2">
              <input
                type="text"
                placeholder="Write a comment..."
                value={commentText}
                onChange={(e) => setCommentText(e.target.value)}
                disabled={submittingComment}
                className="flex-grow px-4 py-2 bg-slate-50 text-slate-800 border border-slate-200 focus:border-[#6366f1] rounded-xl text-sm outline-hidden transition-colors"
                id="comment-input"
              />
              <button
                type="submit"
                disabled={submittingComment || !commentText.trim()}
                className="px-4 bg-[#6366f1] hover:bg-[#4f46e5] disabled:bg-slate-100 disabled:text-slate-400 text-white font-semibold text-xs rounded-xl cursor-pointer transition-colors flex items-center justify-center gap-1.5"
                id="submit-comment-btn"
              >
                <Send className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Add</span>
              </button>
            </div>
          </form>
        )}

        {/* Comments Feed List */}
        {commentsLoading ? (
          <LoadingSpinner size="small" />
        ) : comments.length === 0 ? (
          <div className="text-center text-slate-400 text-xs py-8 font-medium font-mono">
            No comments yet. Drop the first word of encouragement!
          </div>
        ) : (
          <div className="space-y-4 divide-y divide-slate-100" id="comments-list">
            {comments.map((item, index) => {
              const isCommentOwner = user && item.user_id === user.id;
              const isPostOwner = user && post.user_id === user.id;
              const canDelete = isCommentOwner || isPostOwner;

              return (
                <div 
                  key={item.id} 
                  className={`flex gap-3 pt-4 first:pt-0 ${index > 0 ? "pt-4" : ""}`}
                  id={`comment-item-${item.id}`}
                >
                  {/* Commener Avatar */}
                  <img
                    src={item.avatar_url}
                    alt={item.username}
                    onClick={() => navigate("profile", { username: item.username })}
                    className="w-8 h-8 rounded-full object-cover flex-shrink-0 border border-slate-150 cursor-pointer"
                  />

                  {/* Comment Details content */}
                  <div className="flex-grow min-w-0">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span 
                          onClick={() => navigate("profile", { username: item.username })}
                          className="font-sans font-bold text-xs text-slate-900 cursor-pointer hover:text-[#6366f1]"
                        >
                          @{item.username}
                        </span>
                        <span className="text-[10px] text-slate-400 font-mono">
                          {formatRelativeTime(item.created_at)}
                        </span>
                      </div>

                      {/* Delete commenter item only if allowed */}
                      {canDelete && (
                        <button
                          onClick={() => handleDeleteComment(item.id)}
                          className="p-1 text-slate-400 hover:text-rose-600 rounded-lg transition-colors cursor-pointer"
                          title="Delete Comment"
                          id={`delete-comment-${item.id}`}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                    <p className="text-slate-700 text-xs mt-1.5 break-words whitespace-pre-wrap leading-relaxed">
                      {item.text}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        )}

      </div>
    </div>
  );
}
