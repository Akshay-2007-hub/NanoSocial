import React, { useState, useEffect } from "react";
import { useApp } from "../context/AppContext";
import PostComposer from "./PostComposer";
import PostCard from "./PostCard";
import { LoadingSpinner } from "./Feedback";
import { PostType, RelationUser } from "../types";
import { Compass, Users, Sparkles } from "lucide-react";

export default function FeedView() {
  const { apiFetch, showToast, navigate } = useApp();
  const [posts, setPosts] = useState<PostType[]>([]);
  const [suggestedUsers, setSuggestedUsers] = useState<RelationUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [suggestedLoading, setSuggestedLoading] = useState(false);

  const fetchFeed = async () => {
    try {
      const data = await apiFetch<PostType[]>("/api/posts/feed");
      setPosts(data);
    } catch (e: any) {
      showToast(e.message || "Failed to load feed", "error");
    } finally {
      setLoading(false);
    }
  };

  const fetchSuggestions = async () => {
    setSuggestedLoading(true);
    try {
      const users = await apiFetch<RelationUser[]>("/api/users");
      // Pick random 3 users they don't follow yet, or simply take the first 3
      const unfollowed = users.filter((u) => !u.is_following);
      setSuggestedUsers(unfollowed.slice(0, 3));
    } catch (e) {
      console.error("Failed to load suggested users", e);
    } finally {
      setSuggestedLoading(false);
    }
  };

  useEffect(() => {
    fetchFeed();
    fetchSuggestions();
  }, []);

  const handlePostCreated = (newPost: PostType) => {
    // Append at the very top of feed
    setPosts((prev) => [newPost, ...prev]);
  };

  const handlePostDeleted = (postId: string) => {
    setPosts((prev) => prev.filter((p) => p.id !== postId));
  };

  const handleFollowUser = async (targetId: string, username: string) => {
    try {
      const res = await apiFetch(`/api/users/${targetId}/follow`, { method: "POST" });
      showToast(res.following ? `Followed @${username}` : `Unfollowed @${username}`, "success");
      
      // Update local suggested list
      setSuggestedUsers((prev) => 
        prev.map((u) => u.id === targetId ? { ...u, is_following: res.following } : u)
      );

      // Refresh feed
      fetchFeed();
    } catch (e: any) {
      showToast(e.message || "Action failed", "error");
    }
  };

  if (loading) {
    return <LoadingSpinner size="large" />;
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8" id="feed-layout-container">
      
      {/* Primary Feed Column */}
      <div className="lg:col-span-2 space-y-6" id="primary-feed-column">
        
        {/* Post Creator Composer */}
        <PostComposer onPostCreated={handlePostCreated} />

        {/* Posts List container */}
        <div className="space-y-4" id="posts-feed-list">
          {posts.length === 0 ? (
            <div className="bg-white border border-slate-200 rounded-2xl p-10 text-center space-y-4 flex flex-col items-center justify-center shadow-sm" id="empty-feed">
              <div className="w-16 h-16 bg-indigo-50 text-[#6366f1] rounded-2xl flex items-center justify-center p-2 mb-2">
                <Compass className="w-8 h-8" />
              </div>
              <h2 className="font-sans font-bold text-lg text-slate-900 tracking-tight">Your Home Feed is Empty</h2>
              <p className="text-slate-500 font-medium text-sm max-w-sm">
                Follow some creators to curate your daily design and code updates, or check out the Explore stream!
              </p>
              <div className="flex gap-3">
                <button
                  onClick={() => navigate("explore")}
                  className="px-5 py-2 bg-[#6366f1] hover:bg-[#4f46e5] text-white font-semibold text-xs rounded-xl cursor-pointer transition-colors shadow-sm flex items-center gap-1.5"
                >
                  <Compass className="w-4 h-4" />
                  Explore Posts
                </button>
              </div>
            </div>
          ) : (
            posts.map((post) => (
              <PostCard 
                key={post.id} 
                post={post} 
                onPostDeleted={handlePostDeleted} 
              />
            ))
          )}
        </div>
      </div>

      {/* Suggested Creators Sidebar Column */}
      <div className="space-y-6" id="feed-sidebar-column">
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm" id="suggested-panel">
          <div className="flex justify-between items-center mb-4 border-b border-slate-100 pb-3">
            <h3 className="font-sans font-bold text-sm text-slate-900 tracking-tight flex items-center gap-1.5">
              <Users className="w-4.5 h-4.5 text-[#6366f1]" />
              Creators to Follow
            </h3>
            <button 
              onClick={() => navigate("explore")} 
              className="text-xs font-semibold text-[#6366f1] hover:text-[#4f46e5] cursor-pointer bg-transparent border-0 outline-hidden"
            >
              See all
            </button>
          </div>

          {suggestedLoading ? (
            <LoadingSpinner size="small" />
          ) : suggestedUsers.length === 0 ? (
            <p className="text-center text-slate-400 text-xs py-4 font-mono">You follow everyone! 🎉</p>
          ) : (
            <div className="space-y-4" id="suggested-creators-list">
              {suggestedUsers.map((item) => (
                <div 
                  key={item.id} 
                  className="flex items-center justify-between gap-3"
                  id={`suggested-user-${item.id}`}
                >
                  {/* Creator Photo avatar clickable */}
                  <div className="flex items-center gap-3 min-w-0">
                    <img
                      src={item.avatar_url}
                      alt={item.username}
                      onClick={() => navigate("profile", { username: item.username })}
                      className="w-10 h-10 rounded-full object-cover border border-slate-250 cursor-pointer hover:opacity-90 transition-opacity"
                    />
                    
                    {/* Metadata info */}
                    <div className="min-w-0">
                      <p 
                        onClick={() => navigate("profile", { username: item.username })}
                        className="text-sm font-bold text-slate-900 leading-tight cursor-pointer hover:text-[#6366f1] truncate"
                      >
                        @{item.username}
                      </p>
                      <p className="text-slate-400 text-xs truncate leading-none mt-1">
                        {item.followers_count} follower{item.followers_count !== 1 && "s"}
                      </p>
                    </div>
                  </div>

                  {/* Follow button */}
                  <button
                    onClick={() => handleFollowUser(item.id, item.username)}
                    className={`text-xs font-semibold px-3 py-1.5 transition-all rounded-lg cursor-pointer flex-shrink-0 ${
                      item.is_following 
                        ? "bg-slate-100 text-slate-500 border border-slate-200" 
                        : "bg-[#eef2ff] hover:bg-[#e0e7ff] text-[#6366f1] font-semibold"
                    }`}
                  >
                    {item.is_following ? "Following" : "Follow"}
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* NanoSocial Credits footer stats card */}
        <div className="p-5 bg-white border border-slate-200 rounded-2xl flex flex-col justify-center gap-1 text-slate-400 text-xs font-medium font-mono shadow-sm" id="nano-footer-branding">
          <div className="flex items-center gap-1.5 text-slate-500 mb-1 leading-none font-bold">
            <Sparkles className="w-3.5 h-3.5 text-[#6366f1]" />
            <span>NANOSOCIAL v1.1</span>
          </div>
          <p>© 2026 NanoSocial. Made with ❤️ for developers & makers.</p>
        </div>
      </div>

    </div>
  );
}
