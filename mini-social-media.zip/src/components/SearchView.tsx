import React, { useState, useEffect } from "react";
import { useApp } from "../context/AppContext";
import { LoadingSpinner } from "./Feedback";
import { RelationUser } from "../types";
import { Search, UserPlus, UserMinus, ArrowLeft } from "lucide-react";

export default function SearchView({ query }: { query: string }) {
  const { apiFetch, showToast, navigate } = useApp();
  const [results, setResults] = useState<RelationUser[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchResults = async () => {
    setLoading(true);
    try {
      const data = await apiFetch<RelationUser[]>(`/api/users?q=${encodeURIComponent(query)}`);
      setResults(data);
    } catch (e: any) {
      showToast(e.message || "Failed to complete search query", "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchResults();
  }, [query]);

  const handleFollowUser = async (targetId: string, username: string) => {
    try {
      const res = await apiFetch(`/api/users/${targetId}/follow`, { method: "POST" });
      showToast(res.following ? `Followed @${username}` : `Unfollowed @${username}`, "success");
      setResults((prev) =>
        prev.map((u) => (u.id === targetId ? { ...u, is_following: res.following } : u))
      );
    } catch (e: any) {
      showToast(e.message || "Action failed", "error");
    }
  };

  if (loading) {
    return <LoadingSpinner size="large" />;
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6" id="search-view-container">
      {/* Search Header Info */}
      <div className="flex items-center gap-4">
        <button
          onClick={() => navigate("feed")}
          className="p-1.5 hover:bg-slate-50 text-slate-500 hover:text-[#6366f1] transition-all rounded-xl cursor-pointer"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div>
          <h2 className="font-sans font-extrabold text-lg text-slate-900 tracking-tight flex items-center gap-2">
            <Search className="w-5 h-5 text-[#6366f1]" />
            Search Results
          </h2>
          <p className="text-slate-500 text-xs font-medium font-mono">
            Listing creators matching: "{query}"
          </p>
        </div>
      </div>

      {/* Results directory wrapper */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 divide-y divide-slate-100 shadow-sm" id="search-results-list">
        {results.length === 0 ? (
          <div className="text-center text-slate-400 py-12 font-medium">
            No creators or bios matched "{query}". Try checking details!
          </div>
        ) : (
          results.map((item) => (
            <div 
              key={item.id} 
              className="flex items-center justify-between py-4 first:pt-0 last:pb-0 gap-4"
              id={`search-item-${item.id}`}
            >
              <div 
                onClick={() => navigate("profile", { username: item.username })}
                className="flex items-center gap-4 cursor-pointer group"
              >
                <img 
                  src={item.avatar_url} 
                  alt={item.username} 
                  className="w-11 h-11 rounded-full object-cover border border-slate-150 group-hover:scale-102 transition-transform" 
                />
                <div>
                  <p className="text-sm font-extrabold text-slate-900 leading-tight">@{item.username}</p>
                  {item.bio && <p className="text-xs text-slate-500 mt-1 line-clamp-1 max-w-sm sm:max-w-md">{item.bio}</p>}
                </div>
              </div>

              {/* Engagement follow toggle */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleFollowUser(item.id, item.username)}
                  className={`text-xs font-semibold p-1.5 px-3.5 rounded-xl cursor-pointer transition-colors flex items-center gap-1 ${
                    item.is_following
                      ? "bg-slate-100 text-slate-500 hover:bg-slate-200 border border-slate-250"
                      : "bg-[#6366f1] hover:bg-[#4f46e5] text-white"
                  }`}
                >
                  {item.is_following ? (
                    <>
                      <UserMinus className="w-3.5 h-3.5" />
                      Unfollow
                    </>
                  ) : (
                    <>
                      <UserPlus className="w-3.5 h-3.5" />
                      Follow
                    </>
                  )}
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
