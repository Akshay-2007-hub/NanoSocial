import React, { useState } from "react";
import { useApp } from "../context/AppContext";
import { Send, Image, X, Loader2 } from "lucide-react";
import { PostType } from "../types";

interface PostComposerProps {
  onPostCreated: (post: PostType) => void;
}

export default function PostComposer({ onPostCreated }: PostComposerProps) {
  const { user, apiFetch, showToast } = useApp();
  const [content, setContent] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const [showImageInput, setShowImageInput] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!user) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim()) {
      showToast("Post content cannot be empty!", "error");
      return;
    }

    setIsSubmitting(true);
    try {
      const newPost = await apiFetch<PostType>("/api/posts", {
        method: "POST",
        body: JSON.stringify({
          content: content.trim(),
          image_url: imageUrl.trim() || null,
        }),
      });

      setContent("");
      setImageUrl("");
      setShowImageInput(false);
      showToast("Post published successfully!", "success");
      onPostCreated(newPost);
    } catch (err: any) {
      showToast(err.message || "Failed to create post.", "error");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm mb-6" id="post-composer">
      <form onSubmit={handleSubmit}>
        <div className="flex gap-4 items-start">
          <img
            src={user.avatar_url}
            alt={user.username}
            className="w-10 h-10 rounded-full object-cover border border-slate-150"
          />
          <div className="flex-grow">
            <textarea
              placeholder={`What's on your mind, @${user.username}?`}
              value={content}
              onChange={(e) => setContent(e.target.value)}
              disabled={isSubmitting}
              rows={3}
              className="w-full text-slate-800 placeholder-slate-400 border-0 focus:ring-0 text-[15px] outline-hidden resize-none py-1.5 focus:outline-hidden"
              id="composer-textarea"
            />

            {/* Dynamic preview block */}
            {imageUrl.trim() !== "" && (
              <div className="relative mt-3 rounded-2xl overflow-hidden border border-slate-200 max-h-60 group" id="image-preview">
                <img src={imageUrl.trim()} alt="Selected attachments" className="w-full h-full object-cover" />
                <button
                  type="button"
                  onClick={() => setImageUrl("")}
                  className="absolute top-2 right-2 p-1 bg-black/50 hover:bg-black/80 text-white rounded-full transition-colors cursor-pointer"
                  id="remove-image-url"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            )}

            {/* Dynamic image URL expand input */}
            {showImageInput && (
              <div className="mt-3 animate-in fade-in duration-200">
                <div className="flex gap-2">
                  <input
                    type="url"
                    placeholder="Paste an Unsplash or any direct image URL..."
                    value={imageUrl}
                    onChange={(e) => setImageUrl(e.target.value)}
                    disabled={isSubmitting}
                    className="flex-grow px-4 py-1.5 bg-slate-50 border border-slate-200 focus:border-[#6366f1] rounded-xl text-xs outline-hidden transition-colors"
                    id="composer-image-url-input"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      setShowImageInput(false);
                      setImageUrl("");
                    }}
                    className="p-1 px-3 bg-slate-100 text-slate-600 rounded-xl hover:bg-slate-200 text-xs font-semibold cursor-pointer transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="flex justify-between items-center border-t border-slate-100 mt-4 pt-3 flex-wrap gap-2">
          {/* Attachment actions */}
          <div className="flex gap-1">
            <button
              type="button"
              disabled={isSubmitting}
              onClick={() => setShowImageInput(!showImageInput)}
              className={`p-2 rounded-xl transition-colors flex items-center gap-1.5 text-xs font-semibold cursor-pointer ${
                showImageInput || imageUrl
                  ? "bg-[#eef2ff] text-[#6366f1] hover:bg-indigo-100"
                  : "text-slate-500 hover:text-[#6366f1] hover:bg-[#eef2ff]"
              }`}
              id="composer-add-img-btn"
            >
              <Image className="w-4 h-4" />
              <span>{imageUrl ? "Update Image" : "Add Photo"}</span>
            </button>
          </div>

          {/* Submit button */}
          <button
            type="submit"
            disabled={isSubmitting || !content.trim()}
            className="px-5 py-1.5 bg-[#6366f1] hover:bg-[#4f46e5] disabled:bg-slate-100 disabled:text-slate-400 text-white font-semibold text-sm rounded-lg cursor-pointer transition-colors flex items-center gap-1.5 shadow-sm disabled:cursor-not-allowed"
            id="composer-submit-btn"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                Publishing...
              </>
            ) : (
              <>
                <Send className="w-3.5 h-3.5" />
                Publish
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
}
