import React, { useState } from "react";
import { useApp } from "../context/AppContext";
import { Heart, MessageCircle, Trash2, ShieldAlert } from "lucide-react";
import { PostType } from "../types";
import { formatRelativeTime } from "../utils/date";

interface PostCardProps {
  key?: string | number;
  post: PostType;
  onPostDeleted?: (postId: string) => void;
}

export default function PostCard({ post, onPostDeleted }: PostCardProps) {
  const { user, apiFetch, showToast, navigate } = useApp();
  
  // Local interaction states for instant reactive speed
  const [isLiked, setIsLiked] = useState(post.is_liked);
  const [likesCount, setLikesCount] = useState(post.likes_count);
  const [isLiking, setIsLiking] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  // Toggle like logic
  const handleLikeToggle = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isLiking) return;

    // Optimistic UI updates
    const previousLiked = isLiked;
    const previousLikesCount = likesCount;

    setIsLiked(!previousLiked);
    setLikesCount(previousLiked ? previousLikesCount - 1 : previousLikesCount + 1);
    setIsLiking(true);

    try {
      const res = await apiFetch(`/api/posts/${post.id}/like`, { method: "POST" });
      // Sync strictly with server response
      setIsLiked(res.liked);
      setLikesCount(res.likes_count);
      if (res.liked) {
        showToast("Liked post", "success");
      }
    } catch (err: any) {
      // Revert if request fails
      setIsLiked(previousLiked);
      setLikesCount(previousLikesCount);
      showToast(err.message || "Could not save like state.", "error");
    } finally {
      setIsLiking(false);
    }
  };

  const handleDeletePost = async () => {
    setIsDeleting(true);
    try {
      await apiFetch(`/api/posts/${post.id}`, { method: "DELETE" });
      showToast("Post deleted permanently.", "success");
      if (onPostDeleted) {
        onPostDeleted(post.id);
      }
    } catch (err: any) {
      showToast(err.message || "Failed to delete post.", "error");
    } finally {
      setIsDeleting(false);
    }
  };

  const handleCardClick = () => {
    navigate("post", { id: post.id });
  };

  const belongsToCurrentUser = user && post.user_id === user.id;

  return (
    <div 
      onClick={handleCardClick}
      className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs hover:border-slate-300 hover:shadow-md transition-all cursor-pointer relative"
      id={`post-card-${post.id}`}
    >
      {/* Header Info */}
      <div className="flex justify-between items-start mb-3">
        <div 
          onClick={(e) => {
            e.stopPropagation();
            navigate("profile", { username: post.author.username });
          }}
          className="flex items-center gap-3 cursor-pointer group"
        >
          <img
            src={post.author.avatar_url}
            alt={post.author.username}
            className="w-10 h-10 rounded-full object-cover border border-slate-100 group-hover:opacity-90"
          />
          <div>
            <h3 className="font-sans font-bold text-sm text-slate-900 leading-tight">
              @{post.author.username}
            </h3>
            <span className="text-slate-400 text-xs font-medium font-mono leading-none">
              {formatRelativeTime(post.created_at)}
            </span>
          </div>
        </div>

        {/* Delete option only if owned */}
        {belongsToCurrentUser && (
          <div className="relative">
            {showDeleteConfirm ? (
              <div 
                onClick={(e) => e.stopPropagation()}
                className="absolute right-0 top-0 bg-slate-900 border border-slate-800 rounded-xl p-2 shadow-2xl flex items-center gap-2 text-white text-xs whitespace-nowrap z-10"
              >
                <span className="font-medium">Confirm Delete?</span>
                <button
                  onClick={handleDeletePost}
                  disabled={isDeleting}
                  className="bg-rose-600 hover:bg-rose-700 font-semibold px-2 py-0.5 rounded-lg text-[11px] cursor-pointer"
                >
                  Yes
                </button>
                <button
                  onClick={() => setShowDeleteConfirm(false)}
                  className="bg-slate-700 hover:bg-slate-600 font-semibold px-2 py-0.5 rounded-lg text-[11px] cursor-pointer"
                >
                  No
                </button>
              </div>
            ) : (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setShowDeleteConfirm(true);
                }}
                className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                title="Delete Post"
                id={`delete-post-${post.id}`}
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}
          </div>
        )}
      </div>

      {/* Content Text */}
      <p className="text-slate-800 text-sm leading-relaxed mb-4 whitespace-pre-wrap">
        {post.content}
      </p>

      {/* Optional Attachment Image */}
      {post.image_url && (
        <div className="rounded-2xl overflow-hidden mb-4 border border-slate-50 max-h-96">
          <img
            src={post.image_url}
            alt="Upload attachment"
            className="w-full h-full object-cover max-h-96"
            loading="lazy"
          />
        </div>
      )}

      {/* Footer engagement items */}
      <div className="flex items-center gap-6 border-t border-slate-100 pt-3">
        {/* Like Button */}
        <button
          onClick={handleLikeToggle}
          className={`flex items-center gap-1.5 text-xs font-medium p-1.5 px-3 rounded-xl transition-colors cursor-pointer group ${
            isLiked 
              ? "text-rose-500 bg-rose-50" 
              : "text-slate-500 hover:text-rose-500 hover:bg-rose-50"
          }`}
          id={`like-post-btn-${post.id}`}
        >
          <Heart 
            className={`w-4.5 h-4.5 transition-transform group-hover:scale-105 ${
              isLiked ? "fill-rose-500 stroke-rose-500" : "stroke-slate-500"
            }`} 
          />
          <span>{likesCount} Likes</span>
        </button>

        {/* Comment Nav Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            handleCardClick();
          }}
          className="flex items-center gap-1.5 text-xs font-medium text-slate-500 hover:text-[#6366f1] hover:bg-indigo-50/50 p-1.5 px-3 rounded-xl transition-colors cursor-pointer group"
          id={`comment-post-btn-${post.id}`}
        >
          <MessageCircle className="w-4.5 h-4.5 stroke-slate-500 group-hover:stroke-[#6366f1]" />
          <span>{post.comments_count} Comments</span>
        </button>
      </div>
    </div>
  );
}
