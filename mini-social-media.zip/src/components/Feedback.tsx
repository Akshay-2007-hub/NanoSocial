import React from "react";
import { animate, motion, AnimatePresence } from "motion/react";
import { useApp } from "../context/AppContext";
import { CheckCircle2, AlertCircle, Info, Loader2, X } from "lucide-react";

export function ToastContainer() {
  const { toasts, removeToast } = useApp();

  return (
    <div className="fixed top-4 right-4 z-50 flex flex-col gap-2 max-w-sm w-full pointer-events-none" id="toast-wrapper">
      <AnimatePresence>
        {toasts.map((t) => (
          <motion.div
            key={t.id}
            initial={{ opacity: 0, y: -20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -10, scale: 0.9 }}
            transition={{ duration: 0.2 }}
            className={`pointer-events-auto p-4 rounded-xl shadow-lg border flex items-start gap-3 backdrop-blur-md ${
              t.type === "success"
                ? "bg-emerald-50/95 border-emerald-500/20 text-emerald-900"
                : t.type === "error"
                ? "bg-rose-50/95 border-rose-500/20 text-rose-900"
                : "bg-indigo-50/95 border-indigo-500/20 text-indigo-900"
            }`}
            id={`toast-${t.id}`}
          >
            <div className="flex-shrink-0 mt-0.5">
              {t.type === "success" && <CheckCircle2 className="w-5 h-5 text-emerald-600" />}
              {t.type === "error" && <AlertCircle className="w-5 h-5 text-rose-600" />}
              {t.type === "info" && <Info className="w-5 h-5 text-indigo-600" />}
            </div>
            
            <div className="flex-grow text-sm font-medium tracking-tight">
              {t.message}
            </div>

            <button
              onClick={() => removeToast(t.id)}
              className="flex-shrink-0 text-slate-400 hover:text-slate-600 transition-colors p-0.5 rounded-lg hover:bg-slate-100"
              id={`close-toast-${t.id}`}
            >
              <X className="w-4 h-4" />
            </button>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}

export function LoadingSpinner({ size = "medium", overlay = false }: { size?: "small" | "medium" | "large"; overlay?: boolean }) {
  const sizeClasses = {
    small: "w-5 h-5 pointer-events-none",
    medium: "w-8 h-8 pointer-events-none",
    large: "w-12 h-12 pointer-events-none",
  };

  const spinner = (
    <Loader2 className={`animate-spin text-indigo-600 ${sizeClasses[size]}`} />
  );

  if (overlay) {
    return (
      <div className="fixed inset-0 bg-white/70 backdrop-blur-[1px] z-50 flex items-center justify-center" id="global-spinner">
        <div className="bg-white px-6 py-4 rounded-2xl shadow-xl border border-slate-100 flex items-center gap-3">
          {spinner}
          <span className="text-slate-700 font-medium tracking-tight text-sm">Processing...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="flex items-center justify-center py-4" id="inline-spinner">
      {spinner}
    </div>
  );
}
