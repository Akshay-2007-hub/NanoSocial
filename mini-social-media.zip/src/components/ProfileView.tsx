import React, { useState, useEffect } from "react";
import { useApp } from "../context/AppContext";
import { LoadingSpinner } from "./Feedback";
import PostCard from "./PostCard";
import { ProfileData, PostType, RelationUser } from "../types";
import { Edit2, LogOut, CheckCircle2, UserPlus, UserMinus, Grid, Users, Calendar, Mail, FileText, Image, X } from "lucide-react";

export default function ProfileView({ username }: { username: string }) {
  const { user, apiFetch, showToast, navigate, updateUserInContext } = useApp();
  
  // States
  const [profile, setProfile] = useState<ProfileData | null>(null);
  const [posts, setPosts] = useState<PostType[]>([]);
  const [followers, setFollowers] = useState<RelationUser[]>([]);
  const [following, setFollowing] = useState<RelationUser[]>([]);
  
  // Pagination & visual states
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [activeTab, setActiveTab] = useState<"posts" | "followers" | "following">("posts");
  const [showEditModal, setShowEditModal] = useState(false);

  // Profile editing form fields
  const [editBio, setEditBio] = useState("");
  const [editAvatarUrl, setEditAvatarUrl] = useState("");

  const fetchProfileAndContent = async () => {
    setLoading(true);
    try {
      // 1. Get profile stats
      const profileData = await apiFetch<ProfileData>(`/api/users/${username}`);
      setProfile(profileData);
      setEditBio(profileData.bio || "");
      setEditAvatarUrl(profileData.avatar_url || "");

      // 2. Fetch posts made by this user (from explore feed/all posts sorted, filtered locally)
      const allExplorePosts = await apiFetch<PostType[]>("/api/posts/explore");
      const userPosts = allExplorePosts.filter((p) => p.user_id === profileData.id);
      setPosts(userPosts);

      // 3. Fetch followers and following
      const followersData = await apiFetch<RelationUser[]>(`/api/users/${profileData.id}/followers`);
      const followingData = await apiFetch<RelationUser[]>(`/api/users/${profileData.id}/following`);
      setFollowers(followersData);
      setFollowing(followingData);

    } catch (e: any) {
      showToast(e.message || "Failed to load profile", "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProfileAndContent();
  }, [username]);

  const handleFollowToggle = async () => {
    if (!profile) return;

    try {
      const res = await apiFetch(`/api/users/${profile.id}/follow`, { method: "POST" });
      showToast(res.following ? `Followed @${profile.username}` : `Unfollowed @${profile.username}`, "success");
      
      // Update local profile stats accordingly
      setProfile((prev) => prev ? {
        ...prev,
        is_following: res.following,
        followers_count: res.profile.followers_count,
        following_count: res.profile.following_count,
      } : null);

      // Update followers list locally
      if (user) {
        if (res.following) {
          const newFollower: RelationUser = {
            id: user.id,
            username: user.username,
            bio: user.bio,
            avatar_url: user.avatar_url,
            is_following: true,
          };
          setFollowers((prev) => [...prev, newFollower]);
        } else {
          setFollowers((prev) => prev.filter((f) => f.id !== user.id));
        }
      }

    } catch (e: any) {
      showToast(e.message || "Failed to complete follow toggle", "error");
    }
  };

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile) return;

    setSubmitting(true);
    try {
      const updatedProfile = await apiFetch<ProfileData>(`/api/users/${profile.id}`, {
        method: "PUT",
        body: JSON.stringify({
          bio: editBio.trim(),
          avatar_url: editAvatarUrl.trim(),
        }),
      });

      setProfile(updatedProfile);
      updateUserInContext({
        bio: updatedProfile.bio,
        avatar_url: updatedProfile.avatar_url,
      });

      showToast("Profile settings updated successfully!", "success");
      setShowEditModal(false);
    } catch (err: any) {
      showToast(err.message || "Failed to update profile settings.", "error");
    } finally {
      setSubmitting(false);
    }
  };

  const handlePostDeleted = (postId: string) => {
    setPosts((prev) => prev.filter((p) => p.id !== postId));
    // Decrease total posts count locally
    setProfile((prev) => prev ? { ...prev, posts_count: Math.max(0, prev.posts_count - 1) } : null);
  };

  if (loading) {
    return <LoadingSpinner size="large" />;
  }

  if (!profile) {
    return (
      <div className="text-center py-12" id="profile-not-found">
        <h2 className="font-heading font-extrabold text-xl text-slate-900">Creator Profile Not Found</h2>
        <p className="text-slate-500 text-sm mt-1">This user may have deleted their account or changed usernames.</p>
        <button 
          onClick={() => navigate("feed")} 
          className="mt-6 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs rounded-xl cursor-pointer transition-colors"
        >
          Return to Feed
        </button>
      </div>
    );
  }

  const isCurrentUser = user && profile.id === user.id;
  const joinedDate = new Date(profile.created_at).toLocaleDateString(undefined, {
    month: "long",
    year: "numeric",
  });

  return (
    <div className="max-w-3xl mx-auto space-y-8 animate-in fade-in duration-200" id={`profile-page-${profile.username}`}>
      
      {/* 1. Header Card Panel */}
      <div className="bg-white border border-slate-200 rounded-2xl shadow-sm relative overflow-hidden" id="profile-heading-card">
        {/* Colorful gradient back banner */}
        <div className="h-28 bg-gradient-to-r from-[#6366f1] to-[#a855f7]"></div>

        <div className="px-6 pb-6 sm:px-8 sm:pb-8 relative -mt-12 sm:-mt-14 flex flex-col md:flex-row items-center md:items-start md:justify-between text-center md:text-left gap-6 pt-2">
          {/* Main info block */}
          <div className="flex flex-col md:flex-row items-center gap-6">
            <img
              src={profile.avatar_url}
              alt={profile.username}
              className="w-24 h-24 sm:w-28 sm:h-28 rounded-full object-cover border-4 border-white shadow-md flex-shrink-0"
              id="profile-avatar"
            />
            <div className="space-y-2">
              <div className="flex flex-wrap items-center justify-center md:justify-start gap-2.5">
                <h1 className="font-sans font-extrabold text-2xl text-slate-900 tracking-tight">@{profile.username}</h1>
                {isCurrentUser && (
                  <span className="bg-indigo-50 text-indigo-600 text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider">
                    You
                  </span>
                )}
              </div>
              
              {/* Joined Date and Email info */}
              <div className="flex flex-wrap items-center justify-center md:justify-start gap-x-4 gap-y-1 text-xs text-slate-400 font-medium">
                <div className="flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5" />
                  <span>Joined {joinedDate}</span>
                </div>
                {isCurrentUser && (
                  <div className="flex items-center gap-1.5">
                    <Mail className="w-3.5 h-3.5" />
                    <span>{profile.email}</span>
                  </div>
                )}
              </div>

              {/* Bio block description */}
              <p className="text-slate-600 text-sm max-w-md leading-relaxed mt-1">
                {profile.bio || "No profile bio written yet."}
              </p>
            </div>
          </div>

          {/* Action Call to Action */}
          <div className="flex-shrink-0" id="profile-action-panel">
            {isCurrentUser ? (
              <button
                onClick={() => setShowEditModal(true)}
                className="w-full sm:w-auto px-5 py-2 border-0 bg-[#eef2ff] hover:bg-[#e0e7ff] text-[#6366f1] font-bold text-xs rounded-xl cursor-pointer transition-colors flex items-center justify-center gap-2 shadow-xs"
                id="edit-profile-trigger"
              >
                <Edit2 className="w-3.5 h-3.5" />
                Edit Profile
              </button>
            ) : (
              <button
                onClick={handleFollowToggle}
                className={`w-full sm:w-auto px-6 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-md hover:shadow-lg ${
                  profile.is_following
                    ? "bg-slate-150 hover:bg-slate-200 text-slate-700 border border-slate-250"
                    : "bg-[#6366f1] hover:bg-[#4f46e5] text-white"
                }`}
                id="profile-follow-btn"
              >
                {profile.is_following ? (
                  <>
                    <UserMinus className="w-4 h-4" />
                    Unfollow
                  </>
                ) : (
                  <>
                    <UserPlus className="w-4 h-4" />
                    Follow
                  </>
                )}
              </button>
            )}
          </div>
        </div>

        {/* Counts indicators banner */}
        <div className="grid grid-cols-3 gap-4 border-t border-slate-50 mt-8 pt-6 text-center max-w-sm mx-auto md:mx-0" id="profile-counts-indicator">
          <div>
            <p className="font-sans font-extrabold text-lg text-slate-900 leading-tight">{profile.posts_count}</p>
            <p className="text-slate-400 text-xs font-semibold uppercase tracking-wider mt-0.5">Posts</p>
          </div>
          <div className="cursor-pointer hover:bg-slate-50 rounded-xl py-0.5" onClick={() => setActiveTab("followers")}>
            <p className="font-sans font-extrabold text-lg text-slate-900 leading-tight">{profile.followers_count}</p>
            <p className="text-slate-400 text-xs font-semibold uppercase tracking-wider mt-0.5">Followers</p>
          </div>
          <div className="cursor-pointer hover:bg-slate-50 rounded-xl py-0.5" onClick={() => setActiveTab("following")}>
            <p className="font-sans font-extrabold text-lg text-slate-900 leading-tight">{profile.following_count}</p>
            <p className="text-slate-400 text-xs font-semibold uppercase tracking-wider mt-0.5">Following</p>
          </div>
        </div>

      </div>

      {/* 2. Navigation tab selectors */}
      <div className="flex border-b border-slate-200" id="profile-tabs-selector">
        <button
          onClick={() => setActiveTab("posts")}
          className={`flex items-center gap-1.5 px-4 py-3 border-b-2 font-bold text-xs uppercase tracking-wider cursor-pointer transition-all ${
            activeTab === "posts"
              ? "border-[#6366f1] text-[#6366f1]"
              : "border-transparent text-slate-400 hover:text-slate-600"
          }`}
          id="tab-btn-posts"
        >
          <Grid className="w-4 h-4" />
          Posts ({posts.length})
        </button>
        <button
          onClick={() => setActiveTab("followers")}
          className={`flex items-center gap-1.5 px-4 py-3 border-b-2 font-bold text-xs uppercase tracking-wider cursor-pointer transition-all ${
            activeTab === "followers"
              ? "border-[#6366f1] text-[#6366f1]"
              : "border-transparent text-slate-400 hover:text-slate-600"
          }`}
          id="tab-btn-followers"
        >
          <Users className="w-4 h-4" />
          Followers ({followers.length})
        </button>
        <button
          onClick={() => setActiveTab("following")}
          className={`flex items-center gap-1.5 px-4 py-3 border-b-2 font-bold text-xs uppercase tracking-wider cursor-pointer transition-all ${
            activeTab === "following"
              ? "border-[#6366f1] text-[#6366f1]"
              : "border-transparent text-slate-400 hover:text-slate-600"
          }`}
          id="tab-btn-following"
        >
          <Users className="w-4 h-4" />
          Following ({following.length})
        </button>
      </div>

      {/* 3. Render tab contents */}
      <div id="profile-tab-content-grid" className="space-y-4">
        
        {/* Posts Screen */}
        {activeTab === "posts" && (
          <div className="space-y-4 animate-in fade-in duration-150" id="profile-authored-posts">
            {posts.length === 0 ? (
              <div className="bg-white border border-slate-200 rounded-2xl p-10 text-center text-slate-400 text-sm font-medium shadow-sm">
                <FileText className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                This user has not authored any posts yet.
              </div>
            ) : (
              posts.map((post) => (
                <PostCard 
                  key={post.id} 
                  post={post} 
                  onPostDeleted={handlePostDeleted} 
                />
              ))
            )}
          </div>
        )}

        {/* Followers Directory List */}
        {activeTab === "followers" && (
          <div className="bg-white border border-slate-200 rounded-2xl p-5 divide-y divide-slate-100 space-y-1 animate-in fade-in duration-150 shadow-sm" id="profile-followers-list">
            {followers.length === 0 ? (
              <div className="text-center text-slate-400 text-xs py-8 font-medium">
                No followers listed yet.
              </div>
            ) : (
              followers.map((item) => (
                <div 
                  key={item.id} 
                  className="flex items-center justify-between py-4 first:pt-2 last:pb-2 gap-4"
                >
                  <div 
                    onClick={() => navigate("profile", { username: item.username })}
                    className="flex items-center gap-3 cursor-pointer group"
                  >
                    <img src={item.avatar_url} alt={item.username} className="w-10 h-10 rounded-full object-cover border border-slate-250 group-hover:opacity-80" />
                    <div>
                      <p className="text-sm font-bold text-slate-900 leading-tight">@{item.username}</p>
                      {item.bio && <p className="text-xs text-slate-500 mt-0.5 truncate max-w-sm sm:max-w-md">{item.bio}</p>}
                    </div>
                  </div>
                  <button
                    onClick={() => navigate("profile", { username: item.username })}
                    className="px-3 py-1.5 bg-slate-50 hover:bg-slate-100 text-slate-650 font-bold text-[10px] rounded-lg transition-colors cursor-pointer border border-slate-200"
                  >
                    View profile
                  </button>
                </div>
              ))
            )}
          </div>
        )}

        {/* Following Directory List */}
        {activeTab === "following" && (
          <div className="bg-white border border-slate-200 rounded-2xl p-5 divide-y divide-slate-100 space-y-1 animate-in fade-in duration-150 shadow-sm" id="profile-following-list">
            {following.length === 0 ? (
              <div className="text-center text-slate-400 text-xs py-8 font-medium">
                Not following anyone yet.
              </div>
            ) : (
              following.map((item) => (
                <div 
                  key={item.id} 
                  className="flex items-center justify-between py-4 first:pt-2 last:pb-2 gap-4"
                >
                  <div 
                    onClick={() => navigate("profile", { username: item.username })}
                    className="flex items-center gap-3 cursor-pointer group"
                  >
                    <img src={item.avatar_url} alt={item.username} className="w-10 h-10 rounded-full object-cover border border-slate-250 group-hover:opacity-80" />
                    <div>
                      <p className="text-sm font-bold text-slate-900 leading-tight">@{item.username}</p>
                      {item.bio && <p className="text-xs text-slate-500 mt-0.5 truncate max-w-sm sm:max-w-md">{item.bio}</p>}
                    </div>
                  </div>
                  <button
                    onClick={() => navigate("profile", { username: item.username })}
                    className="px-3 py-1.5 bg-slate-50 hover:bg-slate-100 text-slate-650 font-bold text-[10px] rounded-lg transition-colors cursor-pointer border border-slate-200"
                  >
                    View profile
                  </button>
                </div>
              ))
            )}
          </div>
        )}

      </div>

      {/* 4. Overlay Edit Profile Modal Panel */}
      {showEditModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto" id="edit-profile-modal">
          <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl border border-slate-200 overflow-hidden animate-in zoom-in-95 duration-150">
            {/* Header info */}
            <div className="flex justify-between items-center px-6 py-4 border-b border-slate-150">
              <h3 className="font-sans font-bold text-base text-slate-900">Update Profile Bio & Avatar</h3>
              <button 
                type="button" 
                onClick={() => setShowEditModal(false)}
                className="p-1 hover:bg-slate-50 rounded-xl cursor-pointer text-slate-400 hover:text-slate-600 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleUpdateProfile} className="p-6 space-y-4">
              
              {/* Profile Avatar Url update */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block">Avatar Photo URL</label>
                <div className="relative">
                  <input
                    type="url"
                    placeholder="https://example.com/avatar.png"
                    value={editAvatarUrl}
                    onChange={(e) => setEditAvatarUrl(e.target.value)}
                    disabled={submitting}
                    className="w-full pl-10 pr-4 py-2 border border-slate-200 focus:border-[#6366f1] rounded-xl text-sm outline-hidden transition-colors"
                    id="edit-profile-avatar-input"
                  />
                  <Image className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
                </div>
              </div>

              {/* Bio description update */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block">Short Bio</label>
                <textarea
                  placeholder="Tell your followers who you are..."
                  value={editBio}
                  onChange={(e) => setEditBio(e.target.value)}
                  disabled={submitting}
                  rows={4}
                  maxLength={250}
                  className="w-full px-4 py-2 border border-slate-200 focus:border-[#6366f1] rounded-xl text-sm outline-hidden transition-colors resize-none"
                  id="edit-profile-bio-textarea"
                />
                <span className="text-[10px] text-slate-400 font-mono flex justify-end">Max 250 characters</span>
              </div>

              <div className="flex gap-3 justify-end pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowEditModal(false)}
                  disabled={submitting}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-600 font-semibold text-xs rounded-xl cursor-pointer transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-5 py-2 bg-[#6366f1] hover:bg-[#4f46e5] disabled:bg-slate-100 disabled:text-slate-400 text-white font-semibold text-xs rounded-xl cursor-pointer transition-colors shadow-md flex items-center gap-1.5"
                >
                  {submitting ? (
                    <>
                      <LoadingSpinner size="small" />
                      Saving...
                    </>
                  ) : (
                    "Save Changes"
                  )}
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
}
