import React, { useState, useEffect } from "react";
import { useApp } from "../context/AppContext";
import PostCard from "./PostCard";
import { LoadingSpinner } from "./Feedback";
import { PostType } from "../types";
import { Compass, Sparkles, Flame } from "lucide-react";

export default function ExploreView() {
  const { apiFetch, showToast } = useApp();
  const [posts, setPosts] = useState<PostType[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchExplore = async () => {
    try {
      const data = await apiFetch<PostType[]>("/api/posts/explore");
      setPosts(data);
    } catch (e: any) {
      showToast(e.message || "Failed to load explore feed", "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchExplore();
  }, []);

  const handlePostDeleted = (postId: string) => {
    setPosts((prev) => prev.filter((p) => p.id !== postId));
  };

  if (loading) {
    return <LoadingSpinner size="large" />;
  }

  return (
    <div className="space-y-6 max-w-3xl mx-auto" id="explore-view-container">
      {/* Visual Header Grid Accent */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 flex items-center gap-5 shadow-sm" id="explore-header">
        <div className="w-14 h-14 bg-[#eef2ff] text-[#6366f1] rounded-xl flex items-center justify-center">
          <Compass className="w-7 h-7" />
        </div>
        <div>
          <h2 className="font-sans font-extrabold text-xl text-slate-900 tracking-tight flex items-center gap-2">
            Trending Hub 
            <Flame className="w-5 h-5 text-amber-500 fill-amber-100 animate-pulse" />
          </h2>
          <p className="text-slate-500 text-sm font-medium mt-1 leading-relaxed">
            See the absolute newest updates, design snapshots, and code snippets published by makers on NanoSocial.
          </p>
        </div>
      </div>

      {/* Grid container */}
      <div className="space-y-4" id="explore-cards-list">
        {posts.length === 0 ? (
          <div className="bg-white border border-slate-200 rounded-2xl p-10 text-center space-y-4 flex flex-col items-center justify-center shadow-sm" id="explore-empty">
            <Sparkles className="w-12 h-12 text-[#6366f1]" />
            <h3 className="font-sans font-bold text-lg text-slate-900 tracking-tight">No content exists yet</h3>
            <p className="text-slate-500 font-medium text-sm max-w-sm">
              Be the first to post on NanoSocial! Head back to the Home feed and drop your first visual thought.
            </p>
          </div>
        ) : (
          posts.map((post) => (
            <PostCard 
              key={post.id} 
              post={post} 
              onPostDeleted={handlePostDeleted} 
            />
          ))
        )}
      </div>
    </div>
  );
}
