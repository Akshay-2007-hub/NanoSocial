import React, { useState } from "react";
import { useApp } from "../context/AppContext";
import { Eye, EyeOff, Loader2, Sparkles, User, Mail, Lock, Image } from "lucide-react";

const CHOSEN_AVATARS = [
  "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&h=150&fit=crop&crop=face", // Female 1
  "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&h=150&fit=crop&crop=face", // Female 2
  "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150&h=150&fit=crop&crop=face", // Male 1
  "https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=150&h=150&fit=crop&crop=face", // Male 2
  "https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150&h=150&fit=crop&crop=face", // Male 3
  "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&h=150&fit=crop&crop=face", // Female 3
];

export function AuthPage({ mode: initialMode }: { mode: "login" | "register" }) {
  const [mode, setMode] = useState<"login" | "register">(initialMode);
  const { login, apiFetch, showToast, navigate } = useApp();
  
  // Auth Form Fields
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [bio, setBio] = useState("");
  const [customAvatar, setCustomAvatar] = useState("");
  const [selectedAvatar, setSelectedAvatar] = useState(CHOSEN_AVATARS[0]);
  
  // UI states
  const [showPassword, setShowPassword] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!username.trim()) {
      newErrors.username = "Username is required";
    } else if (username.length < 3) {
      newErrors.username = "Username must be at least 3 characters";
    } else if (!/^[a-zA-Z0-9_]+$/.test(username)) {
      newErrors.username = "Username can only contain numbers, letters, and underscores";
    }

    if (mode === "register") {
      if (!email.trim()) {
        newErrors.email = "Email is required";
      } else if (!/\S+@\S+\.\S+/.test(email)) {
        newErrors.email = "Please input a valid email address";
      }
    }

    if (!password) {
      newErrors.password = "Password is required";
    } else if (password.length < 6) {
      newErrors.password = "Password must be at least 6 characters";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    setSubmitting(true);
    try {
      if (mode === "register") {
        const finalAvatar = customAvatar.trim() || selectedAvatar;
        const res = await apiFetch("/api/auth/register", {
          method: "POST",
          body: JSON.stringify({
            username: username.trim(),
            email: email.trim(),
            password,
            bio: bio.trim(),
            avatar_url: finalAvatar,
          }),
        });
        login(res.user, res.token);
      } else {
        const res = await apiFetch("/api/auth/login", {
          method: "POST",
          body: JSON.stringify({
            username: username.trim(),
            password,
          }),
        });
        login(res.user, res.token);
      }
    } catch (err: any) {
      showToast(err.message || "Failed to authenticate. Try again.", "error");
    } finally {
      setSubmitting(false);
    }
  };

  const handleModeSwitch = (newMode: "login" | "register") => {
    setMode(newMode);
    setErrors({});
    navigate(newMode);
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center py-10 px-4 bg-[#f8fafc]" id="auth-page-container">
      <div className="flex w-full max-w-4xl bg-white rounded-2xl overflow-hidden shadow-2xl border border-slate-200 min-h-[580px]">
        
        {/* Branding Sidebar panel on Desktop */}
        <div className="hidden md:flex md:w-1/2 bg-gradient-to-br from-[#6366f1] via-[#4f46e5] to-[#1e1b4b] p-12 text-white flex-col justify-between relative overflow-hidden" id="auth-brand-panel">
          {/* Subtle graphics */}
          <div className="absolute -top-12 -left-12 w-48 h-48 rounded-full bg-white/5 blur-xl"></div>
          <div className="absolute -bottom-12 -right-12 w-64 h-64 rounded-full bg-indigo-500/10 blur-2xl"></div>

          <div 
            onClick={() => navigate("feed")} 
            className="flex items-center gap-2 relative z-10 cursor-pointer group hover:scale-102 transition-transform duration-150 active:scale-98"
            id="auth-logo"
            title="Navigate to Home"
          >
            <div className="w-10 h-10 bg-white/20 backdrop-blur-md rounded-xl flex items-center justify-center text-white font-black text-xl shadow-xs group-hover:bg-white/30 transition-colors">
              N
            </div>
            <span className="font-black text-xl tracking-tight">
              <span className="text-white">Nano</span>
              <span className="text-white/80">Social</span>
            </span>
          </div>

          <div className="relative z-10 my-auto">
            <h1 className="font-sans font-black text-3xl leading-snug tracking-tight">
              {mode === "register" ? "Create your own digital sandbox." : "Reconnect with your community."}
            </h1>
            <p className="text-white/80 font-medium text-sm mt-3 leading-relaxed">
              {mode === "register" 
                ? "Join thousands of creative developers, designers, and students sharing insights globally." 
                : "See what's trending, check followed creative projects, and drop visual comments."}
            </p>
          </div>

          <div className="flex items-center gap-2 text-indigo-205 text-xs font-mono relative z-10">
            <Sparkles className="w-4 h-4 text-amber-305" />
            <span>Designed for responsive visual elegance</span>
          </div>
        </div>

        {/* Input Form Panel */}
        <div className="w-full md:w-1/2 p-8 sm:p-12 flex flex-col justify-center" id="auth-form-panel">
          <div className="mb-8">
            <h2 className="font-sans font-extrabold text-2xl text-slate-900 tracking-tight">
              {mode === "register" ? "Join NanoSocial" : "Welcome Back"}
            </h2>
            <p className="text-slate-500 text-sm font-medium mt-1">
              {mode === "register" ? "Create an account to start posting" : "Enter your details to log in"}
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            
            {/* Username Input */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block">Username</label>
              <div className="relative">
                <input
                  type="text"
                  placeholder="e.g. creative_coder"
                  value={username}
                  onChange={(e) => setUsername(e.target.value.replace(/\s+/g, ""))}
                  disabled={submitting}
                  className={`w-full pl-10 pr-4 py-2 border ${
                    errors.username ? "border-rose-500 focus:border-rose-500" : "border-slate-200 focus:border-[#6366f1]"
                  } rounded-xl text-sm outline-hidden transition-colors bg-white text-slate-900`}
                  id="auth-username"
                />
                <User className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
              </div>
              {errors.username && <p className="text-rose-600 text-xs font-medium">{errors.username}</p>}
            </div>

            {/* Email Input (Register options only) */}
            {mode === "register" && (
              <div className="space-y-1 animate-in fade-in duration-200">
                <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block">Email Address</label>
                <div className="relative">
                  <input
                    type="email"
                    placeholder="you@domain.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    disabled={submitting}
                    className={`w-full pl-10 pr-4 py-2 border ${
                      errors.email ? "border-rose-500 focus:border-rose-500" : "border-slate-200 focus:border-[#6366f1]"
                    } rounded-xl text-sm outline-hidden transition-colors bg-white text-slate-900`}
                    id="auth-email"
                  />
                  <Mail className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
                </div>
                {errors.email && <p className="text-rose-600 text-xs font-medium">{errors.email}</p>}
              </div>
            )}

            {/* Password Input */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block">Password</label>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  disabled={submitting}
                  className={`w-full pl-10 pr-10 py-2 border ${
                    errors.password ? "border-rose-500" : "border-slate-200 focus:border-[#6366f1]"
                  } rounded-xl text-sm outline-hidden transition-colors bg-white text-slate-900`}
                  id="auth-password"
                />
                <Lock className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 top-3 text-slate-400 hover:text-slate-600 transition-colors cursor-pointer"
                  id="toggle-pass-visibility"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              {errors.password && <p className="text-rose-600 text-xs font-medium">{errors.password}</p>}
            </div>

            {/* Bio & Avatar Section (Register mode only expansion) */}
            {mode === "register" && (
              <div className="space-y-4 animate-in fade-in duration-200">
                
                {/* Optional Bio */}
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block">Bio (Optional)</label>
                  <textarea
                    placeholder="Tell us a bit about yourself..."
                    value={bio}
                    onChange={(e) => setBio(e.target.value)}
                    disabled={submitting}
                    rows={2}
                    className="w-full px-4 py-2 border border-slate-200 focus:border-[#6366f1] rounded-xl text-sm outline-hidden transition-colors resize-none bg-white text-slate-900"
                    id="auth-bio"
                  />
                </div>

                {/* Avatar Selection Grid */}
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block">Select an Avatar</label>
                  <div className="grid grid-cols-6 gap-2" id="avatar-grid">
                    {CHOSEN_AVATARS.map((av, index) => (
                      <div 
                        key={av}
                        onClick={() => {
                          setSelectedAvatar(av);
                          setCustomAvatar(""); // Clear custom URL when selecting curated list
                        }}
                        className={`aspect-square rounded-xl overflow-hidden cursor-pointer border-3 transition-all ${
                          selectedAvatar === av && !customAvatar ? "border-[#6366f1] scale-105" : "border-transparent opacity-80"
                        }`}
                      >
                        <img src={av} alt={`Avatar option ${index + 1}`} className="w-full h-full object-cover" />
                      </div>
                    ))}
                  </div>
                </div>

                {/* Custom Avatar URL Field */}
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block">Or Custom Avatar URL</label>
                  <div className="relative">
                    <input
                      type="url"
                      placeholder="https://example.com/your-image.png"
                      value={customAvatar}
                      onChange={(e) => setCustomAvatar(e.target.value)}
                      disabled={submitting}
                      className="w-full pl-10 pr-4 py-2 border border-slate-200 focus:border-[#6366f1] rounded-xl text-sm outline-hidden transition-colors bg-white text-slate-900"
                      id="auth-custom-avatar"
                    />
                    <Image className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
                  </div>
                </div>

              </div>
            )}

            {/* Submission Button */}
            <button
              type="submit"
              disabled={submitting}
              className="w-full py-2.5 bg-[#6366f1] hover:bg-[#4f46e5] disabled:bg-slate-200 disabled:text-slate-405 text-white font-semibold text-sm rounded-xl cursor-pointer transition-colors flex items-center justify-center gap-2 shadow-md hover:shadow-lg disabled:cursor-not-allowed"
              id="auth-submit-btn"
            >
              {submitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Processing request...
                </>
              ) : mode === "register" ? (
                "Create Account"
              ) : (
                "Login with Account"
              )}
            </button>

          </form>

          {/* Nav Mode Switcher Footer */}
          <div className="mt-6 text-center text-sm font-medium text-slate-500 border-t border-slate-100 pt-4" id="auth-footer-switcher">
            {mode === "register" ? (
              <p>
                Already have an account?{" "}
                <button
                  type="button"
                  onClick={() => handleModeSwitch("login")}
                  className="text-[#6366f1] hover:text-[#4f46e5] hover:underline font-bold bg-transparent border-0 p-0 cursor-pointer"
                  id="switch-to-login"
                >
                  Log In
                </button>
              </p>
            ) : (
              <p>
                New to NanoSocial?{" "}
                <button
                  type="button"
                  onClick={() => handleModeSwitch("register")}
                  className="text-[#6366f1] hover:text-[#4f46e5] hover:underline font-bold bg-transparent border-0 p-0 cursor-pointer"
                  id="switch-to-register"
                >
                  Register Now
                </button>
              </p>
            )}
          </div>

        </div>

      </div>
    </div>
  );
}
