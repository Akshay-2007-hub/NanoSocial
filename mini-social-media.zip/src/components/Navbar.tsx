import React, { useState, useEffect, useRef } from "react";
import { useApp } from "../context/AppContext";
import { Compass, Home, Search, LogOut, User as UserIcon, Loader2 } from "lucide-react";
import { RelationUser } from "../types";

export default function Navbar() {
  const { user, logout, navigate, apiFetch, currentRoute } = useApp();
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<RelationUser[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [showDropdown, setShowDropdown] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Search users API call
  useEffect(() => {
    if (!searchQuery.trim()) {
      setSearchResults([]);
      return;
    }

    const delayDebounce = setTimeout(async () => {
      setIsSearching(true);
      try {
        const results = await apiFetch<RelationUser[]>(`/api/users?q=${encodeURIComponent(searchQuery)}`);
        setSearchResults(results);
      } catch (e) {
        console.error("Search error", e);
      } finally {
        setIsSearching(false);
      }
    }, 300);

    return () => clearTimeout(delayDebounce);
  }, [searchQuery]);

  // Close dropdown on click outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setShowDropdown(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  if (!user) return null;

  const handleSearchResultClick = (username: string) => {
    setSearchQuery("");
    setShowDropdown(false);
    navigate("profile", { username });
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setShowDropdown(false);
      navigate("search", { q: searchQuery.trim() });
    }
  };

  return (
    <nav className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-[0_1px_2px_rgba(0,0,0,0.03)] px-4" id="main-navbar">
      <div className="max-w-6xl mx-auto flex items-center justify-between h-16">
        
        {/* Brand Logo */}
        <div 
          onClick={() => navigate("feed")} 
          className="flex items-center gap-2 cursor-pointer group hover:scale-102 transition-transform duration-150 active:scale-98"
          id="nav-logo"
          title="Navigate to Home"
        >
          <div className="w-9 h-9 bg-[#6366f1] rounded-xl flex items-center justify-center text-white font-black text-lg shadow-xs group-hover:bg-[#4f46e5] transition-colors duration-150">
            N
          </div>
          <span className="font-sans font-black text-xl tracking-tight hidden sm:inline-block">
            <span className="text-[#6366f1] group-hover:text-[#4f46e5] transition-colors duration-150">Nano</span>
            <span className="text-[#334155]">Social</span>
          </span>
        </div>

        {/* Global Search Bar */}
        <div className="relative flex-grow max-w-sm mx-4" ref={dropdownRef} id="nav-search-container">
          <form onSubmit={handleSearchSubmit}>
            <div className="relative">
              <input
                type="text"
                placeholder="Search usernames or bios..."
                value={searchQuery}
                onFocus={() => setShowDropdown(true)}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setShowDropdown(true);
                }}
                className="w-full pl-9 pr-4 py-1.5 bg-slate-50 border border-slate-200 focus:border-[#6366f1] rounded-xl text-sm outline-hidden transition-colors focus:bg-white text-[#1e293b]"
                id="search-input"
              />
              <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
              {isSearching && (
                <Loader2 className="absolute right-3 top-2.5 w-4 h-4 text-indigo-500 animate-spin" />
              )}
            </div>
          </form>

          {/* Quick Search Action Dropdown */}
          {showDropdown && (searchQuery.trim() !== "" || searchResults.length > 0) && (
            <div 
              className="absolute top-12 left-0 right-0 bg-white border border-slate-200/80 shadow-2xl rounded-2xl p-1 overflow-hidden max-h-80 overflow-y-auto z-50 animate-in fade-in slide-in-from-top-1 duration-150"
              id="search-dropdown"
            >
              {searchResults.length === 0 ? (
                <div className="p-4 text-center text-slate-400 text-xs font-mono">
                  No matching creators found
                </div>
              ) : (
                searchResults.map((item) => (
                  <div
                    key={item.id}
                    onClick={() => handleSearchResultClick(item.username)}
                    className="flex items-center gap-3 p-2.5 hover:bg-slate-50 rounded-xl cursor-pointer transition-colors"
                  >
                    <img
                      src={item.avatar_url}
                      alt={item.username}
                      className="w-8 h-8 rounded-full object-cover border border-slate-100"
                    />
                    <div className="flex-grow min-w-0">
                      <p className="text-sm font-semibold text-slate-900 leading-tight">@{item.username}</p>
                      {item.bio && (
                        <p className="text-xs text-slate-500 truncate mt-0.5">{item.bio}</p>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
        </div>

        {/* Navigation Actions */}
        <div className="flex items-center gap-1 sm:gap-3" id="nav-actions">
          <button
            onClick={() => navigate("feed")}
            className={`p-2.5 rounded-xl transition-colors cursor-pointer relative ${
              currentRoute.name === "feed"
                ? "text-indigo-600 bg-indigo-50/50"
                : "text-slate-500 hover:text-slate-800 hover:bg-slate-50"
            }`}
            title="Home Feed"
            id="nav-btn-feed"
          >
            <Home className="w-5 h-5" />
          </button>

          <button
            onClick={() => navigate("explore")}
            className={`p-2.5 rounded-xl transition-colors cursor-pointer relative ${
              currentRoute.name === "explore"
                ? "text-indigo-600 bg-indigo-50/50"
                : "text-slate-500 hover:text-slate-800 hover:bg-slate-50"
            }`}
            title="Explore Trending"
            id="nav-btn-explore"
          >
            <Compass className="w-5 h-5" />
          </button>

          <button
            onClick={() => navigate("profile", { username: user.username })}
            className={`p-2.5 rounded-xl transition-colors cursor-pointer flex items-center gap-2 ${
              currentRoute.name === "profile" && currentRoute.params?.username === user.username
                ? "text-indigo-600 bg-indigo-50/50 border border-indigo-200/20"
                : "text-slate-500 hover:text-slate-800 hover:bg-slate-50"
            }`}
            title="My Profile"
            id="nav-btn-profile"
          >
            <img
              src={user.avatar_url}
              alt={user.username}
              className="w-5.5 h-5.5 rounded-full object-cover border border-slate-200"
            />
            <span className="font-medium text-sm hidden md:inline">@{user.username}</span>
          </button>

          <div className="h-6 w-[1px] bg-slate-200 mx-1 hidden sm:block"></div>

          <button
            onClick={logout}
            className="p-2.5 rounded-xl text-slate-500 hover:text-rose-600 hover:bg-rose-50/50 transition-colors cursor-pointer"
            title="Sign Out"
            id="nav-btn-logout"
          >
            <LogOut className="w-5 h-5" />
          </button>
        </div>

      </div>
    </nav>
  );
}
