/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { AppProvider, useApp } from "./context/AppContext";
import Navbar from "./components/Navbar";
import { AuthPage } from "./components/AuthPages";
import FeedView from "./components/FeedView";
import ExploreView from "./components/ExploreView";
import ProfileView from "./components/ProfileView";
import PostDetailsView from "./components/PostDetailsView";
import SearchView from "./components/SearchView";
import { ToastContainer, LoadingSpinner } from "./components/Feedback";

function AppContent() {
  const { currentRoute, user, isLoading, isInitializing } = useApp();

  if (isInitializing) {
    return (
      <div className="min-h-screen bg-slate-100 flex items-center justify-center p-4" id="app-init-loader">
        <LoadingSpinner size="large" />
      </div>
    );
  }

  const isAuthRoute = currentRoute.name === "login" || currentRoute.name === "register";

  if (!isAuthRoute && !user) {
    return (
      <div className="min-h-screen bg-slate-100 flex items-center justify-center p-4" id="app-auth-loader">
        <LoadingSpinner size="large" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-100 text-slate-800" id="nano-app-content">
      {/* 1. Header Navigation Bar (only if authenticated and non-auth screen) */}
      {!isAuthRoute && <Navbar />}

      {/* 2. Main Visual Body Segment */}
      <main className={`${isAuthRoute ? "" : "max-w-6xl mx-auto px-4 py-8"}`}>
        {currentRoute.name === "login" && <AuthPage mode="login" />}
        {currentRoute.name === "register" && <AuthPage mode="register" />}
        
        {/* Render pages with Auth Guard (checking if logged in) */}
        {!isAuthRoute && (
          <>
            {currentRoute.name === "feed" && <FeedView />}
            {currentRoute.name === "explore" && <ExploreView />}
            {currentRoute.name === "profile" && (
              <ProfileView username={currentRoute.params?.username || user?.username || ""} />
            )}
            {currentRoute.name === "post" && (
              <PostDetailsView postId={currentRoute.params?.id || ""} />
            )}
            {currentRoute.name === "search" && (
              <SearchView query={currentRoute.params?.q || ""} />
            )}
          </>
        )}
      </main>

      {/* 3. Global Dynamic Alerts & Spinner feedback */}
      <ToastContainer />
      {isLoading && <LoadingSpinner overlay={true} />}
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}

