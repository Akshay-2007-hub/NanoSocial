export interface AuthUser {
  id: string;
  username: string;
  email: string;
  bio: string;
  avatar_url: string;
  created_at: string;
}

export interface ProfileData extends AuthUser {
  posts_count: number;
  followers_count: number;
  following_count: number;
  is_following: boolean;
}

export interface Author {
  id: string;
  username: string;
  avatar_url: string;
}

export interface PostType {
  id: string;
  user_id: string;
  content: string;
  image_url: string;
  created_at: string;
  author: Author;
  likes_count: number;
  comments_count: number;
  is_liked: boolean;
}

export interface CommentType {
  id: string;
  post_id: string;
  user_id: string;
  text: string;
  created_at: string;
  username: string;
  avatar_url: string;
}

export interface RelationUser {
  id: string;
  username: string;
  bio: string;
  avatar_url: string;
  is_following: boolean;
}

export type RouteName = "login" | "register" | "feed" | "explore" | "profile" | "post" | "search";

export interface Route {
  name: RouteName;
  params?: Record<string, string>;
}

export interface Toast {
  id: string;
  message: string;
  type: "success" | "error" | "info";
}
